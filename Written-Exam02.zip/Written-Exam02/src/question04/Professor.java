/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question04;

/**
 *
 * @author S542295
 */
public class Professor {
    String designation = "Professor";
   String collegeName = "Northwest Missouri State University";
   void does(){
	System.out.println("Lectures");
   }
}
