/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question05;

/**
 *
 * @author S542295
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person person = new Person("Abhi","111 East 11th street","1244667890","test@gmail.com");
        Student student = new Student("A", "Dumala","603 east 7th street","123456726","testing@gmail.com");
        Employee employee = new Employee("Reception office",1234,"03-12-2019","Abhilash","122 East 11th street","1234127834","testad@gmail.com");
        Faculty faculty = new Faculty(4,2,"ECE",1342,"10-11-2016","Raj","123 East 11th street","123456677","testin1@gmail.com");
        Staff staff = new Staff("Teacher","Admisitation",1435,"11-03-2012","Jashwanth","603 east 7th street","1234567890","jas@nomail.com");
        System.out.println(person);
        System.out.println(student);
        System.out.println(employee);
        System.out.println(faculty);
        System.out.println(staff);
    }
    
}
