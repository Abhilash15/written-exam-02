/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question03;

/**
 *
 * @author S542295
 */
public class Loan {
    private String name;
    private double givenAmount;
    private double interestRate;

    public Loan(String name, double givenAmount, double interestRate) {
        this.name = name;
        this.givenAmount = givenAmount;
        this.interestRate = interestRate;
    }

    public String getName() {
        return name;
    }

    public double getGivenAmount() {
        return givenAmount;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAmount(double givenAmount) {
        this.givenAmount = givenAmount;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    @Override
    public String toString() {
        return "Loan taken by : " + name + ", Amount given initially " + givenAmount + " with an interestRate=" + interestRate ;
    }
}
